#!/bin/bash
./bashtime_lists.sh
