#! /usr/bin/env python
import subprocess
_rc0 = subprocess.call(["./bashtime_lists.sh"],shell=True)
